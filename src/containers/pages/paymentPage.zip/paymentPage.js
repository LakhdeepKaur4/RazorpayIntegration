import React, { Component,useEffect } from 'react';
import { Row, Col } from 'reactstrap';
// import { Label, Button, Row, Col } from 'reactstrap';
// import { Link } from 'react-router-dom';
import { bindActionCreators } from 'redux';
import { connect } from 'react-redux';
import { getData } from '../../redux/paymentPage/action';

class Payment extends Component {
        
    constructor(props) {
        super(props);

        this.state = {
            show: false,
            cardNo: '',
            cvvNo: '',
            expiryDate: ''
        }

        console.log('wdcwdc');
    }
    componentDidMount(){
        this.props.getData();
    }

    addCard = (e) => {
        e.preventDefault();
        console.log('hii');
        this.setState({ show: true });
    }
    change = (e) => {
        this.setState({ [e.target.name]: e.target.value })

    }
    submit = () => {
        console.log(this.state);
        this.props.value(this.state);
        this.setState({ show: false });

    }
    showData({paymentData}){
        if(paymentData){
            console.log(paymentData);
        }
            
        

    }

    render() {
        console.log('asdbchadbsc');
        return (
            <div>
                <div className="card ">
                    <h2 className="mt-2"><b>Payment Options</b></h2>
                </div>
                <div className='mt-1  ml-3 mb-2'><span>CREDIT/DEBIT CARD</span></div>
                {this.state.show ? <div className="card">
                    <div className=" jumbotron border border-dark ">

                        <h3>Enter Card Details</h3>
                        <div><input type="text" name='cardNo' placeholder='Enter Card No' onChange={this.change} style={{ marginBottom: '5px' }} /></div>
                        <div><input type="number" name='cvvNo' placeholder='Enter cvv no ' onChange={this.change} style={{ marginBottom: '5px', marginTop: '5px' }} /></div>
                        <div><input type="date" name='expiryDate' placeholder='Enter expiry no ' onChange={this.change} style={{ marginTop: '5px' }} /></div>
                        <div><button onClick={this.submit} style={{ marginTop: '5px', border: '1px solid orange', background: 'white' }}>Submit</button></div>
                    </div>

                </div>
                    : ''}
                <div className="card mt-3">
                    <div className="mt-4 ml-2">
                        <Row>
                            <Col xs="3">
                                <button style={{ margin: '0px 0px 0px 10px', border: '1px solid orange', background: 'white' }}
                                    onClick={this.addCard}
                                >+</button>
                            </Col>
                            <Col xs="9">
                                <div><strong className="text-warning"><b>ADD A NEW CARD</b></strong></div>
                                <div><h5>Save and pay via Cards</h5></div>
                            </Col>
                        </Row>
                    </div>
                </div>
                <div className="ml-3 mt-2"><span>UPI</span></div>
                <div className="card mt-2">
                    <div className="mt-2 ml-2">
                        <Row>
                            <Col xs="3">
                                <button style={{ margin: '0px 0px 0px 10px', border: '1px solid orange', background: 'white' }}>+</button>
                            </Col>
                            <Col xs="9">
                                <div><strong style={{ color: 'orange' }}>ADD A NEW UPI</strong></div>
                                <div><h5>You need to have a registered UPI Id</h5></div>
                            </Col>
                        </Row>
                    </div>
                </div>
                <div className="m-2">Wallets</div>
                <div className="card mt-2">
                    {this.showData(this.props.payment)}
                    {/* <div className="mt-2">
                        <Row>
                            <Col xs="3">
                                <span className="ml-2"><img src="https://cdn.razorpay.com/bank/HDFC.gif"/></span>
                            </Col>
                            <Col xs="5">
                                <div><h5>Amazon Pay</h5></div>
                            </Col>
                            <Col xs="4">
                                <a className='nav-link text-warning'>Link Account</a>
                            </Col>

                        </Row>
                    </div>
                    <hr />


                    <div className="mt-2">
                        <Row>
                            <Col xs="3">
                                <span className="ml-2"><img src="https://cdn.razorpay.com/app/phonepe.svg"/></span>
                            </Col>
                            <Col xs="5">
                                <div><h5>Phone Pay</h5></div>
                            </Col>
                            <Col xs="4">
                                <a className='nav-link text-warning'>Link Account</a>
                            </Col>
                        </Row>
                    </div>
                    <hr />


                    <div className="mt-2">
                        <Row>
                            <Col xs="3">
                                <span className="ml-2"><img src="https://cdn.razorpay.com/app/paytm.svg"/></span>
                            </Col>
                            <Col xs="5">
                                <div><h5>Paytm</h5></div>
                            </Col>
                            <Col xs="4">
                                <a className='nav-link text-warning'>Link Account</a>
                            </Col>
                        </Row>
                    </div>

                    <div className="mt-2">
                        <Row>
                            <Col xs="3">
                                <span className="ml-2">Image</span>
                            </Col>
                            <Col xs="5">
                                <div><h5>Mobiwik</h5></div>
                            </Col>
                            <Col xs="4">
                                <a className='nav-link text-warning'>Link Account</a>
                            </Col>
                        </Row>
                    </div>
                    <hr />

                    <div className="mt-2">
                        <Row>
                            <Col xs="3">
                                <span className="ml-2"><img src="https://cdn.razorpay.com/app/googlepay.svg"/></span>
                            </Col>
                            <Col xs="5">
                                <div><h5>Google Pay</h5></div>
                            </Col>
                            <Col xs="4">
                                <a className='nav-link text-warning'>Link Account</a>
                            </Col>
                        </Row>
                    </div> */}

                </div>
            </div>
        )
    }
}
function mapStateToProps(state) {
    return {
        payment: state.payment
    }
}

function mapDispatchToProps(dispatch) {
    return bindActionCreators({ getData }, dispatch)
}

export default connect(mapStateToProps, mapDispatchToProps)(Payment);